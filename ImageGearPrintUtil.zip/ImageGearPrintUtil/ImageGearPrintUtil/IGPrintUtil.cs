﻿using System;
using System.Runtime.InteropServices;
using GearCORELib;
using GearDISPLAYLib;

namespace ImageGearPrintUtil
{
    [ProgId("ImageGearPrintUtil.IGPrintUtility")]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [Guid("415D09B9-3C9F-43F4-BB5C-C056263EF270")]
    [ComVisible(true)]

    public class IGPrintUtility
    {
        public System.Drawing.Printing.PrintDocument PrintD;
        private IGDocument document;
        private int currentPageNumber = 0;
        private void PrintD_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            IntPtr graphicsHdc = e.Graphics.GetHdc();
            IGDisplayCtl displayCtl1 = new IGDisplayCtl();
            IGPage currentPage = document.Page[this.currentPageNumber];
            IGPageDisplay pageDisplay = displayCtl1.CreatePageDisplay(currentPage);

            pageDisplay.PrintDirect = true;
            pageDisplay.PrintImage(graphicsHdc.ToInt32());

            e.Graphics.ReleaseHdc(graphicsHdc);

            //If there is another page left in the document continue adding pages
            if (this.currentPageNumber + 1 < document.PageCount)
            {
                this.currentPageNumber++;
                //returning while HasMorePages is true will call this function again to add the next page
                e.HasMorePages = true;
                return; 
            }
            else
            {
                e.HasMorePages = false;
            }
        }

        [ComVisible(true)]
        public void PrintWithIG(IGDocument doc)
        {
            this.document = doc;
            this.PrintD = new System.Drawing.Printing.PrintDocument();
            this.PrintD.DocumentName = "ImageGear document";
            this.PrintD.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintD_PrintPage);
            PrintD.Print();
        }
    }
}